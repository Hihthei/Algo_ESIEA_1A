# Space_ptr* #

Vous êtes un pointeur dans le tas, combatez les Buffer_Overflows. Attention à ne pas pointer sur NULL !


# Ajouts :

-> structure du code :
	- principalement des pointeurs

-> Auto guidage des énemies, des balles enemies et des balles du joueur (touche 'S')
-> dégats de collisions avec les enemies
-> Sons & bruitages
-> Différents patternes
-> Pointeurs sur fonction
-> différents menus


Il y a plusieurs niveaux, plusieurs paternes, autant pour les bullets que pour les enemies


# Feedback :
On aurait aimé faire plus mais la mise en place de la structure du code nous
a pris beaucoup de temps.

Le principal avantage de notre code c'est qu'on peu ajouter énormément de patternes
très facilement. Toutes les "briques" sont là et il ne faut plus que les assembler.