# Space_ptr*

## Ajouts :

-> Auto guidage
-> Son
-> Différents patterns
-> Code basé avec principalement des pointeurs
-> Pointeurs sur fonction

Il y a plusieurs niveaux, plusieurs paternes, autant pour les bullets que pour les enemies


## Feedback :
On aurait aimé faire plus mais la mise en place de la structure du code nous
a pris beaucoup de temps.

Le principal avantage de notre code c'est qu'on peu ajouter énormément de patterns
très facilement. Toutes les "briques" sont là et il ne faut plus que les assembler.

## Fait avec amour par:
Nicolas BADIN et Célin BOUILLON
