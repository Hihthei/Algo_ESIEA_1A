#pragma once

#include "Scene.h"

void craft_level_1(Scene *s);
void craft_level_1_boss(Scene *s);
void craft_level_2(Scene *s);
void craft_level_2_boss(Scene *s);
void craft_level_3(Scene *s);
void craft_level_4(Scene *s);
void craft_level_4_5(Scene *s);
void craft_level_4_boss(Scene *s);
