#pragma once
#ifndef FUNCTION_H_
#define FUNCTION_H_

void printf_k(int hehehe);





#endif