#include "InputGroup.h"

InputGroup::InputGroup() :
    m_enabled(false)
{
}

InputGroup::~InputGroup()
{
}

void InputGroup::OnPreEventProcess()
{
}

void InputGroup::OnEventProcess(SDL_Event evt)
{
}

void InputGroup::Reset()
{
}
