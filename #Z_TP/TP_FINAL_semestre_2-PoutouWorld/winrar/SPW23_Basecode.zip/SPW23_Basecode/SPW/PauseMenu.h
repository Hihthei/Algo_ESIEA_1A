#pragma once

#include "Settings.h"
#include "UIObject.h"

class LevelScene;

class PauseMenu : public UIObject
{
public:
    PauseMenu(LevelScene &scene);
};