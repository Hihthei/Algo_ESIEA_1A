#pragma once

#include "Settings.h"
#include "UIObject.h"

class TitleScene;

class LevelSelection : public UIObject
{
public:
    LevelSelection(TitleScene &scene);
};